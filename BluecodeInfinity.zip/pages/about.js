import {  SiLinkedin, SiTwitter, SiFacebook } from "react-icons/si";

const AboutUs = () => {
    return(
        <main className="bg-white">

        </main>
        
    )
}
export default AboutUs;