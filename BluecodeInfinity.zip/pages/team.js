import {  SiLinkedin, SiTwitter, SiFacebook } from "react-icons/si";

const WhyUs = () => {
    return(
        <main className="bg-white">

        </main>
        
    )
}
export default WhyUs;