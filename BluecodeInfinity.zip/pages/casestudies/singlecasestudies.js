import {  SiLinkedin, SiTwitter, SiFacebook } from "react-icons/si";

const SingleCase = () => {
    return(
        <main className="bg-white">

        </main>
        
    )
}
export default SingleCase;