"use strict";
exports.id = 211;
exports.ids = [211];
exports.modules = {

/***/ 2211:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);



const Expertise = ()=>{
    const { 0: activeExpertise , 1: setActiveExpertise  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("healthcare");
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "py-24",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-2 lg:hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-gray-200 text-3xl font-semibold tracking-widest",
                        children: "Our industries expertise"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-2 gap-2 py-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-gray-700 to-gray-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "01"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Healthcare"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-purple-600 to-purple-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "02"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Education"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-purple-600 to-purple-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "03"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Logistics"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-gray-700 to-gray-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "04"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Marketplace"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-gray-700 to-gray-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "05"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Media"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-purple-600 to-purple-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "06"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Retail"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-purple-600 to-purple-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "07"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Fintech"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col justify-start items-start bg-gradient-to-r from-gray-700 to-gray-600 p-3 rounded-md ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-white text-2xl font-bold tracking-widest",
                                        children: "08"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white text-lg font-semibold",
                                        children: "Travel"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "hidden lg:grid grid-cols-3 space-x-20",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-span-1 px-4 space-y-8",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-gray-200 text-5xl font-semibold tracking-widest",
                                children: "Our industries expertise"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "px-5 space-y-8",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "01"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('healthcare')
                                                ,
                                                className: `${activeExpertise === 'healthcare' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Healthcare"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "02"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('education')
                                                ,
                                                className: `${activeExpertise === 'education' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Education"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "03"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('logistics')
                                                ,
                                                className: `${activeExpertise === 'logistics' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Logistics"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "04"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('marketplace')
                                                ,
                                                className: `${activeExpertise === 'marketplace' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Marketplace"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "05"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('media')
                                                ,
                                                className: `${activeExpertise === 'media' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Media"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "06"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('retail')
                                                ,
                                                className: `${activeExpertise === 'retail' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Retail"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "07"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('fintech')
                                                ,
                                                className: `${activeExpertise === 'fintech' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Fintech"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex justify-start items-center gap-5 text-3xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-gray-500",
                                                children: "08"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                onClick: ()=>setActiveExpertise('travel')
                                                ,
                                                className: `${activeExpertise === 'travel' ? "text-blue-600" : ""} text-white hover:text-blue-600 cursor-poine cursor-pointer`,
                                                children: "Travel"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'healthcare' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/healthcare.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'education' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/education.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'logistics' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/logistics.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'marketplace' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/marketplace.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'media' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/media.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'retail' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/retail.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'fintech' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/fintech.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${activeExpertise === 'travel' ? "" : "hidden"}  col-span-2 flex flex-col justify-start items-start   space-y-8`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                alt: "Image Alt",
                                src: "/images/travel.webp",
                                width: 2400,
                                height: 1500,
                                layout: "intrinsic",
                                objectFit: "cover" // Scale your image down to fit into the container
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-blue-600 text-3xl ",
                                children: "Custom EHR, EMR, ERX, and other software solutions for Healthcare and Medicine"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-200 ",
                                children: "We help established businesses such as hospitals, laboratories, and pharmacies, create turnkey products, and simplify digital transformation."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-blue-500 underline underline-offset-4 hover:no-underline hover:bg-opacity-10 hover:bg-blue-200 py-1 px-2 hover:rounded-full",
                                children: "Discover industry details"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Expertise);


/***/ })

};
;